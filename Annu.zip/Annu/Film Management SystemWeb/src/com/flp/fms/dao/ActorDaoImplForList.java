package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Language;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ActorDaoImplForList  implements IActorDao  {

	@Override
	public List<Actor> getActors() {
		
		
		//implement the database connectivity for getting actor details
		
		Connectionclass conn = new Connectionclass();
		Connection newconnection=  conn.getConnection();
		
		List<Actor> actorss = new ArrayList<>();
		
		//execute query
		boolean flag=false;
		String sql = "select * from actor";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Actor actors = new Actor();
				
				actors.setActorId(rs.getInt(1));
				actors.setFirstName(rs.getString(2));
				actors.setLastName(rs.getString(3));
				actorss.add(actors);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return actorss;
	}
	
		
}
		
		
		
		
		
		
		
	


