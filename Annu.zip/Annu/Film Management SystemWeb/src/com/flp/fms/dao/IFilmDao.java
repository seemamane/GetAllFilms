package com.flp.fms.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	
List< Language> getLanguages();
List<Category>  getCategory();
List<Film> getAllFilms();
public void addFilm(Film film);
//public Film searchfilmbyid( int filmid);
//public Film searchfilmbyname( String filmname);
//public Film searchfilmbyrating( int filmrating);

}
