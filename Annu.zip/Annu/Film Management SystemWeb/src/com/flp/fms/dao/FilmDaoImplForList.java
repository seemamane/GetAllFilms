package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList  implements IFilmDao {

private Map<Integer, Film> film_repository = new HashMap<>();
	@Override
	public List<Language> getLanguages() {
		
		List<Language> languages = new ArrayList<>();
		//implement data base connection
		Connectionclass conn = new Connectionclass();
		Connection newconnection=  conn.getConnection();

		boolean flag=false;
		String sql = "select * from language";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Language language = new Language();
				
				language.setLanguageId(rs.getInt(1));
				language.setLanguageName(rs.getString(2));
				languages.add(language);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return languages;
	}
		/*languages.add(new Language(1,"Malayalam"));
		languages.add(new Language(2,"KANNADA"));
		languages.add(new Language(3,"TELUGU"));
		languages.add(new Language(4,"TAMIL"));
		languages.add(new Language(5,"MARATI"));
		languages.add(new Language(6,"HINDI"));
		languages.add(new Language(7,"URUDU"));*/
		
		
	

    @Override
	public List<Category> getCategory() {
		List<Category> categorys = new ArrayList<>();
		
		Connectionclass conn = new Connectionclass();
		Connection newconnection=  conn.getConnection();

		boolean flag=false;
		String sql = "select * from category";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				Category category = new Category();
				
			   category.setCategoryId(rs.getInt(1));
			   category.setName(rs.getString(2));
			
			   categorys.add(category);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return categorys;

		
	}

    
    
	@Override
	public List<Film> getAllFilms() {
		Film film =new Film();
		Connectionclass conn = new Connectionclass();
		Connection newconnection=  conn.getConnection();
		boolean flag=false;
		int filmId=0;
		String sql = "select * from film";
		PreparedStatement stmt;
		try {
			
			stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();	
			
			while(rs.next())
			{
				
				
			   film.setFilmid(rs.getInt(1));
			   film.setTitle(rs.getString(2));
			   film.setDescription(rs.getString(3));
			   film.setReleaseYear(rs.getDate(4));
			   film.setRentalDuration(rs.getDate(7));
			   film.setLength(rs.getInt(8));
			   film.setReplacementcost(rs.getDouble(9));
			   film.setRatings(rs.getInt(10));
			   film.setSpecialfeatures(rs.getString(11));
			   String sql1= "select * from "
			
			   categorys.add(category);
			}
			
			flag = true;
			} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		return categorys;

		return null;
	}

	
	
	@Override
	public void addFilm(Film film) {
		
		
	Connectionclass conn = new Connectionclass();
	Connection newconnection=  conn.getConnection();
	
	String sql="insert into film(title,description,releaseYear,categoryId,originalLanguageId,rentalDuration,length,replacementCost,rating,specialfeatures)"
			+"values(?,?,?,?,?,?,?,?,?,?)";
	PreparedStatement pst;
	try {
		
		pst = newconnection.prepareStatement(sql);
		
		pst.setString(1, film.getTitle());
		pst.setString(2, film.getDescription());			
		pst.setDate(3, new java.sql.Date(film.getReleaseYear().getTime()));
		pst.setInt(4, film.getCategory().getCategoryId());
		pst.setInt(5,film.getOriginalLanguage().getLanguageId());
		pst.setDate(6, new java.sql.Date(film.getRentalDuration().getTime()));
		pst.setInt(7, film.getLength());
		pst.setDouble(8,film.getReplacementcost());
		pst.setInt(9, film.getRatings());
		pst.setString(10, film.getSpecialfeatures());
		
		int count=pst.executeUpdate();
		
		System.out.println(count);
		
		
		//if insertion to film table is success execute
		if(count>0){
			
			//insertion to third party tables
			int filmId=0;
			
			sql="select count(title) from film";
					
			PreparedStatement stmt = newconnection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
					
				filmId = rs.getInt(1);
			}
		
		sql="insert into film_actors(filmId,actorId) values(?,?)";
		pst = newconnection.prepareStatement(sql);
		
		//getting all the actors in the film
		List<Actor> actors = (List<Actor>) film.getActors();				
		for(Actor act: actors){
			pst.setInt(1, filmId );
			pst.setInt(2, act.getActorId() );
			
			count=pst.executeUpdate();
		}
		
						
		sql="insert into film_languages(filmId,languageId) values(?,?)";
		pst = newconnection.prepareStatement(sql);
		
		//getting all the other languages
		List<Language> languages = film.getLanguage();				
		for(Language lang: languages){
			pst.setInt(1, filmId );
			pst.setInt(2, lang.getLanguageId());
			
			count=pst.executeUpdate();
		}
		
	}
	
} catch (SQLException e) {
	e.printStackTrace();
}
	}

	
	

	
	
    
    
    
	
	
}
