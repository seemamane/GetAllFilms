package com.flp.fms.util;

import java.util.Iterator;
import java.util.List;

import com.flp.fms.domain.Language;

public class Validate {

	//validate title
	public static boolean isValidTitle(String title){
		return title.matches("[A-Za-z0-9.,! ]+");
	}
	
	//validate length
	public static boolean isValidlength(int length){
		boolean flag=false;
		if(length>=1&&length<=1000)
		{flag=true;}
		return flag;
	    }
	
	//validate rating
		public static boolean isValidrating(int rating){
			boolean flag=false;
			if(rating>=1&&rating<=5)
			{flag=true;}
			return flag;
		    }
		
	//validate date
	public static boolean isValidDate(String myDate){
		return myDate.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
	}
	
	//validate rental date
	public static boolean isValidRentalDate(String rentaldate){
		return rentaldate.matches("[0123][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-[12][890]\\d{2}");
	}

	 //validate replacement cost
	 public static boolean isvalidreplacementcost(String cost)
	 {
		 return cost.matches("[0-9]+");
		 
	 }
	
	//validate repetition of list of languages
	public static boolean checkDuplicateLanguage(List<Language> languages,Language language){
			
			boolean flag=false;
			
			Iterator<Language> it= languages.iterator();
			if(languages.isEmpty())
			{
				flag=false;
			}
			else
			{
				while(it.hasNext()){
					
			Language language2=it.next();
			if(language.equals(language2))
					{
						flag=true;
						break;
					}
			}
			}
			return flag;
}

}