package com.flp.fms.view;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import com.flp.fms.domain.Language;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Film;
import com.flp.fms.util.Validate;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	
//Return fully qualified film object
	public Film addFilm(List<Language> languages ,List<Category> categories,List<Actor> actor){
		Film film=new Film();
		boolean flag=true;
		
//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		title=sc.nextLine();
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
		
//Get length and validate length
	    int length =0;
			do{
				System.out.println("Enter Film length");
				length=sc.nextInt();
				flag=Validate.isValidlength(length);
					if(!flag)
						System.out.println("Invalid length. Please Enter Valid length!");
				}while(!flag);
				film.setLength(length);
				
//Get rating and validate it
			   int rating =0;
				do{
				System.out.println("Enter Film Rating");
				rating=sc.nextInt();
				flag=Validate.isValidrating(rating);
					if(!flag)
					System.out.println("Invalid Rating. Please Enter Valid rating!");
				}while(!flag);
				film.setRatings(rating);
	
// get special feature
	 String specialfeature =null;
	 System.out.println("Enter Film Special Feature");
	 specialfeature=sc.next();
	 film.setSpecialfeatures(specialfeature);
	   
// get description
	   String description =null;
		System.out.println("Enter Film Description");
		description=sc.next();
		 film.setDescription(description);
				
//Get relese date and validate relese date
		String relesedate = null;
		boolean releseflag = false;
		Date releseDate;
		
	do{
	//verify date format
		do{
			System.out.println("Enter Film relese date");
			relesedate=sc.next();
			
			flag=Validate.isValidDate(relesedate);
				if(!flag)
				System.out.println("Invalid relese date format!");
		} while(!flag);
		
		//verify relese date
		     Date today=new Date();
		     releseDate = new Date(relesedate);
		     if(releseDate.before(today)||releseDate.equals(today))
			 releseflag  = true;
		     
		    if(!releseflag)
			System.out.println("Invalid relese date. Date should be current date or past date!");
	        }while(!releseflag);
	        film.setReleaseYear(releseDate);
	        
	     
	        
//get rental date and verify it
				String rentaldate = null;
				boolean rentalflag = false;
				Date rentalDate;
		
				
		//verify date format
						do{
							System.out.println("Enter Film rental date");
							rentaldate =sc.next();
							flag=Validate.isValidRentalDate(rentaldate);
							if(!flag)
								System.out.println("Invalid rental date format!");
							
							else{
			
								rentalDate = new Date( rentaldate);
								if(film.getReleaseYear().before(rentalDate))
								{
									film.setRentalDuration(rentalDate);
								     flag = true;
								}
									
								else{
							    	
							    	flag=false;
							    	System.out.println("Invalid rental date. Date should be current date or past date!");
							    }
								
							}
								
						  } while(!flag);
						
						
				        
				        
				    
						
	  //replacement cost get and validATE
					
					do{
					System.out.println(" enter the replacemnt cost");
					int cost = sc.nextInt();
				    String costt = Integer.toString(cost);
				    flag=Validate.isvalidreplacementcost(costt);
				    film.setReplacementcost(cost);
					if(!flag)
					System.out.println("Invalid Special Features. Please Enter Valid features!");
				     }while(!flag);
				     
					
					// accepting original language
					Language lang =selectlanguage( languages);
					film.setOriginalLanguage(lang);
					
				//Adding all languages
					List<Language> languages2=new ArrayList<>();
					String choice;
					boolean flag_langs;
					do{
						System.out.println("Choose All Languages for the Film:");
						Language language1= selectlanguage(languages);
						
						
						flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
						if(!flag_langs)
							languages2.add(language1);
						else
							System.out.println("Language already Exists. Please try other languages!");
						
						
						System.out.println("Wish to add More Languages?[y|n]");
						choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
					film.setLanguage(languages2);
					
					//accepting original cateogory
					Category cat =selectcategory(categories);
					film.setCategory(cat);
					
				    //add actors
					List<Actor> actors2=new ArrayList<>();
					do{
						System.out.println("Choose All Actors for the Film:");
						Actor actor1=addactor(actor);
						actors2.add(actor1);
						
						System.out.println("Wish to add More Actors?[y|n]");
						choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
					
			          film.setActors(actors2);
					
					
					
					
						
		return film;
	}

	//method for accepting language
public Language selectlanguage(List<Language> languages )
{
	boolean flag =false;
	Language language = null;
	do{
		System.out.println(" the list of languages are");
		for(Language lang: languages) 
		{
			
			System.out.println(lang.getLanguageId()+" \t"+lang.getLanguageName());
		}
		System.out.println(" Enter your choice");
		int option =sc.nextInt();
		for(Language lang: languages) 
		{
			
			if(lang.getLanguageId()==option)
			{
				flag = true;
				language = lang;
				break;
			}
			
		}
		if( !flag)
		{
			System.out.println(" enter valid id");
		}
	}while(!flag);
	
	return language;
}

//method for accepting category
public Category selectcategory(List<Category> category )	
{
	Category cate = null;
	boolean flag = false;
	do{
		System.out.println(" The list of category are");
		for(Category cat: category) 
		{			
			System.out.println(cat.getCategoryId()+" \t"+cat.getName());
		}
		
		System.out.println(" Enter your choice");
		int option =sc.nextInt();
		for(Category cat: category) 
		{
			
			if(cat.getCategoryId()==option)
			{
				flag = true;
				cate = cat;
				break;
			}
			
		}
		if( !flag)
		{
			System.out.println(" enter valid id");
		}
    	}while(!flag);
			
	return cate;
}

//get actor names
    public Actor addactor(List<Actor> actor)
    {
    	Actor set_actor =null;
    	boolean flag = false;
    	do{
    		for(Actor actr: actor)
    		{
    			System.out.println(actr.getActorId() + "\t" + actr.getFirstName() + "\t" + actr.getLastName());
    		}
    		System.out.println("Choose the Actor form the set given below:");
    		int option=sc.nextInt();
    		flag=false;
    		
    	// check the actor object
    		for(Actor actr:actor)
    		{
    			if(option==actr.getActorId())
    			{
    				set_actor=actr;
    				flag=true;
    				break;
    			}
    		
    		}
    	if(!flag)
    	
    		System.out.println("Please select valid Actor Id");
		}while(!flag);	
		
		return set_actor;
    	
    	
    	}
    	
    public void getallfilms( Collection<Film> films)
    {
    	for(Film film:films){
			String languages="";
			for(Language language:film.getLanguage())
				languages=languages+language.getLanguageName()+",";
			String Actors="";
			
			for(Actor actrs:film.getActors())
				Actors=Actors+actrs.getFirstName()+"\t"+actrs.getLastName();
			System.out.println("film Id"+"\t"+"Film Title" +"\t"+"Relese Year"+"\t"+"Rental Duration"+"\t"+"Special Features"+"\t"+"Description"+"\t"+"Replacement Cost"+"\t"+"Rating"+"\t"+"Languages"+"\t"+"Actors");
			System.out.println(film.getFilmid() + "\t" +
					film.getTitle() + "\t"+
					film.getReleaseYear() + "\t"+
					film.getRentalDuration()+"\t"+
					film.getSpecialfeatures()+"\t"+
					film.getDescription()+"\t"+
					film.getReplacementcost()+"\t"+
					film.getRatings()+"\t"+languages+"\t"+Actors);
    }
 
    }
    
//method to search film by id
  public void searchfilmbyid(Collection<Film> lst){
  System.out.println(" enter the film id to search");
  int film_id = sc.nextInt();
  boolean flagid=false;
  if(lst.isEmpty())
  {
	  System.out.println(" Film repository is Empty");
  }
  else{
  for(Film film:lst)
  {
  if(film_id==film.getFilmid())
  {
	  System.out.println(lst);
	  flagid=true;
	  break;
  }
  }
  if(flagid==false)
  {
	  System.out.println(" film not found");}
  }
  }
  
  
  // method to search film by name
  public void searchfilmbyname(Collection<Film> lst){
	  System.out.println(" enter the film name to search");
	  String film_name = sc.nextLine();
	  boolean flagname=false;
	  if(lst.isEmpty())
	  {
		  System.out.println(" Film repository is Empty");
	  }
	  else{
	  for(Film film:lst)
	  {
	  if(film.getTitle().equals(film_name))
	  {
		  System.out.println(film);
		  flagname=true;
		  break;
	     }
	  }
	  if(flagname==false)
	  {
		  System.out.println(" film not found");}
  		}
	  }
  
  // method to search film by rating
  public void searchfilmbyrating(Collection<Film> lst){
	  System.out.println(" enter the film rating to search");
	  int film_rating= sc.nextInt();
	  boolean flagrating=false;
	  if(lst.isEmpty())
	  {
		  System.out.println(" Film repository is Empty");
	  }
	  else{
	  for(Film film:lst)
	  {
	  if(film_rating==film.getRatings())
	  {
		  System.out.println(film);
		  flagrating=true;
		  break;
	  }
	  }
	  if(flagrating==false)
	  {
		  System.out.println(" film not found");}
  		}
	  }
  
 //method to remove film by id
  public void removefilmbyid(Collection<Film> films)
  {
	  System.out.println(" enter the id to remove the film");
	  int film_id =sc.nextInt();
	  boolean flag=false;
	  if(films.isEmpty())
	  {
		  System.out.println(" Film repository is Empty");
	  }
	  else{
	  for(Film film: films)
	  if(film_id==film.getFilmid())
	  {
		  films.remove(film);
		  flag = true;
		  break;
	  }
	if(flag ==false)
	  {System.out.println(" film not found");  }
	  }
  }
  
  //method to remove film by rating
  public void removefilmbyrating(Collection<Film> films)
  {
	  System.out.println(" enter the rating to remove the film");
	  int film_rating =sc.nextInt();
	  boolean flag=false;
	  if(films.isEmpty())
	  {
		  System.out.println(" Film repository is Empty");
	  }
	  else{
	  for(Film film: films)
	  if(film_rating==film.getRatings())
	  {
		  films.remove(film);
		  flag = true;
		  break;
	  }
	if(flag ==false)
	  {System.out.println(" film not found");}
  }
  } 
  
  //method to remove film byname
  public void removefilmbyname(Collection<Film> films)
  {
	  System.out.println(" enter the name  to remove the film");
	  String film_name=sc.nextLine();
	  boolean flag=false;
	  if(films.isEmpty())
	  {
		  System.out.println(" Film repository is Empty");
	  }
	  else{
	   for(Film film: films)
	   if(film_name.equals(film.getTitle()))
	    {
		  films.remove(film);
		  flag = true;
		  break;
	     }
	   if(flag ==false)
	  {System.out.println(" film not found");}
	  }
  } 
  
}




