package com.flp.fms.view;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmSerivice;

public class BootClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option;
		UserInteraction userInteraction=new UserInteraction();
		IFilmSerivice filmservice = new FilmServiceImpl();
		IActorService actorservice = new  ActorServiceImpl();
		String choice;
	do{
		menuSelectionforfilm();
		System.out.println("Enter your option:[1-6]");
		option=sc.nextInt();
		switch(option){
			case 1:
				Film film=userInteraction.addFilm(filmservice.getLanguages(),filmservice.getCategory(),actorservice.getActors());
				//System.out.println(film);
				filmservice.addFilm(film);
				break;
			case 2:
				break;
			case 3:
		  //remove films by various options
				Film film1;
				int searchoption1;
				menuSelectionfordeletfilm();
				System.out.println(" enter your choice how you would like do the Remove" );
				searchoption1= sc.nextInt();
				switch(searchoption1)
				{
		   //remove films by id
				case 1:
					List<Film>  filmlst11= filmservice.getAllFilms();
					Collection<Film> lst11=((Map<Integer, Film>) filmlst11).values();
					userInteraction.removefilmbyid(lst11);
				break;
		 //remove films by name
				case 2:
					List<Film>  filmlst12= filmservice.getAllFilms();
					Collection<Film> lst12=((Map<Integer, Film>) filmlst12).values();
					userInteraction.removefilmbyname(lst12);
					break;
		  //remove films by rating
				case 3:
					List<Film>  filmlst13= filmservice.getAllFilms();
					Collection<Film> lst13=((Map<Integer, Film>) filmlst13).values();
					userInteraction.removefilmbyrating(lst13);
					break;
				}
				
				break;
		//search for films by various options
			case 4:
				Film film2;
				int searchoption2;
				menuSelectionforsearchfilm();
				System.out.println(" enter your choice how you would like do the serch" );
				searchoption2= sc.nextInt();
		   
			switch(searchoption2)
				{
			//search film by id
			case 1:
					List< Film>  filmlst2= filmservice.getAllFilms();
					Collection<Film> lst2=((Map<Integer, Film>) filmlst2).values();
					userInteraction.searchfilmbyid(lst2);
					
					break;
		   //search film by name
			case 2:
					List< Film>  filmlst3= filmservice.getAllFilms();
					Collection<Film> lst3=((Map<Integer, Film>) filmlst3).values();
					userInteraction.searchfilmbyname(lst3);
					break;
		    //search film by rating
			case 3:
					List<Film>  filmlst4= filmservice.getAllFilms();
					Collection<Film> lst4=((Map<Integer, Film>) filmlst4).values();
					userInteraction.searchfilmbyrating(lst4);
					break;
				
					}
				break;
				
				//get all films in the repository
			case 5:
				List< Film>  filmlst= filmservice.getAllFilms();
				Collection<Film> lst=((Map<Integer, Film>) filmlst).values();
				userInteraction.getallfilms(lst);
				break;
			case 6:
				System.exit(0);
		}
		
		System.out.println("Wish to do more Operation?[y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
	}

	

	public static void menuSelectionforfilm(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}
	public static void menuSelectionforsearchfilm(){
		System.out.println("1.Search by film ID");
		System.out.println("2.Search by Film Name");
		System.out.println("3.Search by Film Rating");
		
		
	}
	
	public static void menuSelectionfordeletfilm(){
		System.out.println("1.Remove by film ID");
		System.out.println("2.Remove by Film Name");
		System.out.println("3.Remove by Film Rating");
		
		
	}
	public static void menuSelectionforupdate(){
		System.out.println("1.update by film ID");
		System.out.println("2.update by Film Name");
		System.out.println("3.update by Film Rating");
		
		
	}
}