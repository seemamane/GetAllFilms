package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmSerivice;

/**
 * Servlet implementation class listallfilmservlet
 */
public class listallfilmservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		IFilmSerivice ifms = new FilmServiceImpl();
	   List <Film>films =   ifms.getAllFilms();
	    
	    if(films==null)
	    {
	    	request.getRequestDispatcher("createfilmservlet").forward(request, response);
	    }
	    else
	    {
	    	PrintWriter out=response.getWriter();
	    	out.println("<!DOCTYPE html>");
	    	out.println("<html>");
	    	out.print("<head>");
	    	out.print("<meta charset='ISO-8859-1'>");
	    	out.print("<title>Insert title here</title>");
	    	out.print("</head>");
	    	out.print("<body>");
	    	out.print("<h1 Style='color:blue' align='center'>The list of Films in  Film Repository is Shown Here </h1>");
	    	out.print("<form>");
	    	out.print("<table>");
	    	out.print("<tr>");
	    	out.println("<th> Film Id </th>");
	    	out.println("<th> Film Name </th>");
	    	out.println("<th> Release Year </th>");
	    	out.println("<th> Rental Duration </th>");
	    	out.println("<th> Length </th>");
	    	out.println("<th> Ratings </th>");
	    	out.println("<th> Category </th>");
	        out.println("<th> Original Language </th>");
	        out.println("<th> Languages </th>");
	        out.println("<th> Actor List </th>");
	        out.println("<th> Description</th>");
	        out.println("<th> Special Features</th>");
	        out.println("<th> Replacement Cost</th>");
	        out.print("</tr>");
	    	out.print("</form>");
	        out.print("</table>");
	        out.print("</body>");
	        out.print("</html>");
	        
	        // getting 
	    	for(Film film:films)
	    	{
	    		out.println("<tr>");
				out.println("<td>"+film.getFilmid()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getReleaseYear()+"</td>");
				out.println("<td>"+film.getRentalDuration()+"</td>");
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getRatings()+"</td>");
				out.println("<td>"+film.getCategory().getName()+"</td>");
				
				out.println("<td>"+film.getOriginalLanguage().getLanguageName()+"</td>");
				out.println("<td>");
				
				for(Language lang: film.getLanguage()){					
					out.println(lang.getLanguageName()+", ");
				}
				out.println("</td>");
	    	    out.println("</td>");
	    	    
	    	    for(Actor act: film.getActors()){					
					out.println(act.getFirstName()+" "+act.getLastName()+", ");
				}
			   
			    out.println("<td>");
			
			    out.println("</td>");
			    out.println("<td>"+film.getDescription()+"</td>");
			    out.println("<td>"+film.getReplacementcost()+"</td>");
			    out.println("<td>"+film.getSpecialfeatures()+"</td>");
			    out.println("</tr>");
		}	
		out.println("</table></body>");
		
		out.println("</html>");		
	}
}
	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    
		
		
	
	}


