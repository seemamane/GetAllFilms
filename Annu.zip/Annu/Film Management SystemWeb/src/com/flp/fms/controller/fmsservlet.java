package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class fmsservlet
 */
public class fmsservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.print("<head>");
		out.print("<meta charset='ISO-8859-1'>");
		out.print("<title>Success Page</title>");
        out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
        out.print("</head>");
        out.print("<body>");
        out.print("<div>");
        out.print("<h1 align='center'>Film Management  System</h1>");
        out.print("<hr>");
        out.print("</div>");
        out.print("<div>");

        out.print("<div id='menu'>");
        out.print("<div id='menuItem'>");
        out.print("<a href='createfilmservlet' target='empCnt'>Add Film</a>");
        out.print("	<a href='#'>Modify Film</a>");
        out.print("<a href='#''>Remove Film</a>");
        out.print("<a href='ListAllEmpServlet' target='empCnt'>Search Film</a>");
        out.print("<a href='listallfilmservlet'>GetAll Film</a>");
        out.print("<a href='#'>Exit</a>");
        out.print("</div>");
        out.print("</div>");
        out.print("<div id='mainCnt'>");
        out.print("<iframe name='empCnt' style='margin:0; width:900px; height: 500px;' src='createfilmservlet' > </iframe>");


        out.print("</div>");
        out.print("</div>");
        out.print("<div id='footer'>");
        out.print("<div style=' width:200px;float:left; font-weight: bold; color:white; font-size: 12px;margin-left: 10px;''>ADM FLP Batch</div>");

        out.print("<div style='width:100px;float:left; padding-left:550px; font-weight: bold; color:white; font-size: 12px;margin-left: 10px;''>8-Feb-2016</div>");
        out.print("</div>");
        out.print("</body>");
        out.print("</html>");
		
		
		
		
		
	}

}
