package com.flp.fms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmSerivice;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
/**
 * Servlet implementation class addfilmservlet
 */
public class addfilmservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Film film= new Film();
		
		//adding the title
		String title=request.getParameter("filmTitle");
		film.setTitle(title);
		
		//adding the length
	   int len=Integer.parseInt(request.getParameter("length"));
	   film.setLength(len);
	   
	   //adding the category
	   Category cat= new Category();
	   int categoryid=Integer.parseInt(request.getParameter("category"));
	   cat.setCategoryId(categoryid);
	   film.setCategory(cat);
	   
	   
       
	   
	   //adding the  multiple languages
	   
	   List<Language> languages2=new ArrayList<>();
	   Language lan= new Language();
	   
	   String languagevalue= null;
	   languagevalue=request.getParameter("Lang");
	   lan.setLanguageName(languagevalue);
	   languages2.add(lan);
	   film.setLanguage(languages2);
	   
	   
	    //adding the  original language
	     Language originallan = new Language();
	   
	     int originallanguage_id=Integer.parseInt(request.getParameter("originalLang"));
	     originallan.setLanguageId(originallanguage_id);
	     film.setOriginalLanguage(originallan);
	    
	     
	     
	    
		   //adding actors
	       List<Actor> actors=new ArrayList<>();
		   Actor act= new Actor();
		   int actorid=Integer.parseInt(request.getParameter("actor"));
		   act.setActorId(actorid);
	       actors.add(act);
	       film.setActors(actors);
	       
	       
	       
	       
	       //adding rating
	       int rating=Integer.parseInt(request.getParameter("rating"));
	       film.setRatings(rating);
	       
	       //adding relese year
	      String relyear=request.getParameter("releaseYear");
	      Date releseyear= new Date(relyear);
	      film.setReleaseYear(releseyear);
	      
	      
	      //adding Rental Duration
	      
	      String rentalduration=request.getParameter("rentalDate");
	      Date rentduration= new Date(rentalduration);
	      film.setRentalDuration(rentduration);
	      
	      
	      //adding replacemnt cost
	      
	      int replacmentcost=Integer.parseInt(request.getParameter("cost"));
	      film.setReplacementcost(replacmentcost);
	      
	      
	     //adding specialfeatures
	      String specialfeature=request.getParameter("specialfeatures");
	      film.setSpecialfeatures(specialfeature);
	      
	     
	     //adding description
	      String description=request.getParameter("description");
	      film.setDescription(description);
		 
		  IFilmSerivice ifms = new FilmServiceImpl();
		  ifms.addFilm(film);
	
	   
	   
	}

}
