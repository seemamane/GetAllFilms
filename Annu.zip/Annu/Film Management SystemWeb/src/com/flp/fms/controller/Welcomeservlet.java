package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Welcomeservlet
 */
public class Welcomeservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.print("<head>");
		out.print("<meta charset='ISO-8859-1'>");
		out.print("<title>Insert title here</title>)");
		out.print("</head>");
		out.print("<body style='background-color:lightgreen'>");
		out.print("<h2> Welcome to the Film Management System</h2>");
		out.print("<br>");
		out.print("<br>");
		out.print("<a href='fmsservlet' target=''>Click here to visit the Film Management Repository</a>");
		out.print("</body>");
		out.print("</html>");
		
	}

	
	
	
}
