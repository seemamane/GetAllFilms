package com.flp.fms.controller;



import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;


public class createfilmservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		FilmServiceImpl filmserviceimpl=new FilmServiceImpl();
		ActorServiceImpl actorserviceimpl=new ActorServiceImpl();
		
		
		List<Actor> actor=actorserviceimpl.getActors();
		List<Language> langauge=filmserviceimpl.getLanguages();
		List<Category> category=filmserviceimpl.getCategory();
		
		out.print("<html>");
		out.print("<head>");
		out.print("<script type='text/javascript' src='script/validation.js'></script>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.print("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>");
		out.print("<script src='//code.jquery.com/jquery-1.10.2.js'></script>");
		out.print("<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>:");
		out.print("<script>");
		out.print("$(function() {");
		out.print("$( '#datepicker' ).datepicker();");
		out.print(";});");
		out.print("$(function() {");
        out.print("$( '#datepicker2' ).datepicker();");
        out.print(" $( '#datepicker2' ).datepicker('show');");
        out.print("; });");
		out.print("</script>");
		out.print("</head>");
		
		out.print("<body style=Background-color:lightblue>");
		out.print("<form name='film' method='post' action='addfilmservlet' onsubmit='return validateForm()'>");
		out.print("<h1 align='center'><i>Add Films Here</i></h1>");
		out.println("<table>" +
				"<tr>" +
				"<td>Film Title:</td>" +
				"<td><input type='text' name='filmTitle' size='20'>" +
				"<div id='title_div'  class='errMsg'></div></td>" +
				"</tr>");
		out.print("<tr>"
				+ "<td>Desciption:</td>"
				+ "<td><textarea rows='4' name='description' cols='25'></textarea></td><"
				+ "/tr>");
		out.print("<tr>"
				+ "<td>Special Features:</td>"
				+ "<td><textarea rows='4'  cols='25' name='specialfeatures' size='20' onmouseout='return specialFeatureValidation()'></textarea></td>"
				+"<div id='featureErr' class='errMsg'></div>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Length Of Film:</td>"
				+ "<td><input type='text' name='length' size='20' onmouseout='return lengthValidation()'></td>"
				+ "<td><div id='length_div'  class='errMsg'></div></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Release Year:</td>"
				+ "<td><input type='text'id='datepicker' name='releaseYear' size='20'></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Rental Duration:</td>"
				+ "<td><input type='text'id='datepicker2' name='rentalDate' size='20'></td>"
				+"<td><div id='rental_div' class='errMsg'></div></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Replacement Cost:</td>"
				+ "<td><input type='text' name='cost' size='20'></td>"
				+"<td><div id='cost_div' class='errMsg'></div></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Ratings:</td>"
				+ "<td><select name='rating'>"
				+ "<option value='1'>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>	"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"
				+ "</select></td>"
				+ "</tr>");
		out.print("<tr><td>Original Language:</td>"
					+ "<td><select name='originalLang'>");
			for(Language lang:langauge){
				out.print("<option value="+lang.getLanguageId() +">"+lang.getLanguageName()+"</option>");
			}
		out.print("</select></td></tr>");
		
		out.print("<tr><td>Language:</td>"
				+ "<td><select name='Lang' multiple>");
		for(Language lang:langauge){
			out.print("<option>"+lang.getLanguageName()+"</option>");
		}
	out.print("</select></td></tr>");
	
		out.print("<tr><td>Category:</td>"
				+ "<td><select name='category'>");
			for(Category categorys:category){
					out.print("<option value="+ categorys.getCategoryId()+">"+categorys.getCategoryId()+" "+categorys.getName()+"</option>");
				}
		out.print("</select></td></tr>");
	
		out.print("<tr><td>Actor:</td>"
				+ "<td><select name='actor' multiple>");
			for(Actor actors:actor){
			out.print("<option value="+actors.getActorId()+">"+actors.getFirstName()+" "+actors.getLastName()+"</option>");
				}
		out.print("</select></td></tr>");
		
		out.print("<tr><td></td>"
				+ "<td><input style='Background-color:red' type='submit' value='Save'</td>"
				+ "<td><input style='Background-color:red' type='reset' value='Clear'</td>"
			+ "</tr>");
			
		out.print("</table></form>");
		out.print("</body></html>");
		
					
		
	}

}
