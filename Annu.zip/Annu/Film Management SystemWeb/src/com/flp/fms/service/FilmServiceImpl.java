package com.flp.fms.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmSerivice  {

	private IFilmDao filmDao = new FilmDaoImplForList ();
	
	@Override
	public List<Language> getLanguages(){
		
	return filmDao.getLanguages();
	}
 
	@Override
	public List<Category> getCategory() {
	return filmDao.getCategory();
		
	}
	
// get all filims to the repository
	@Override
	public List<Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

//oveeride the add filim method of ifilim dao
	@Override
	public void addFilm(Film film) {
		
		//film.setFilmid(generateFilm_Id());
		
		filmDao.addFilm(film);
	}
	
//generate film id randomly
	public int generateFilm_Id(int film_id)
	{
		//int film_id;
//Verify filmId has been Duplicated or not
		/*do{
			double fid = Math.random()*1000;
			film_id = (int)fid;
		}while(checkduplicateFilmid(film_id));*/
		
		return film_id;
	}
	
//check duplicate film IDS
//public boolean checkduplicateFilmid(int filmid)
{
	/*List<Integer> keys= ((Object) getAllFilms()).keySet();
	boolean flag=false;
	if(keys.isEmpty() || keys==null){
		flag= false;
	}else{
		for(Integer key:keys){
			if(key==filmid){
				flag=true;
				break;
			}*/
		
	
	
	//return flag;
}

/*@Override
public Film searchfilmbyid(int filmid) {
	
	 return filmDao.searchfilmbyid(filmid);
}

@Override
public Film searchfilmbyname(String filmname) {
	
	return filmDao.searchfilmbyname(filmname);
}

@Override
public Film searchfilmbyrating(int filmrating) {
	
	return filmDao.searchfilmbyrating(filmrating);
}*/
	



	
	
}
