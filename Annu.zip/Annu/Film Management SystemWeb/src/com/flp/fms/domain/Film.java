//Filim Class
package com.flp.fms.domain;
import  java.util.Date;
import  java.util.List;
import java.util.Set;

public class Film {

	private int Filmid;
	private String title;
	private String description;
	private Date ReleaseYear;
	private List<Language> language;
	private Language originalLanguage;
	private Date rentalDuration;
	private  int length;
	private int replacementcost;
	private int ratings;
	private String specialfeatures;
	private List<Actor> actors;
	private Category category;
	
/*no agrument constructor*/public Film(){}

//Argument constructor//
public Film(int filmid, String title, String description, Date releaseYear, List<Language> language,
		Language originalLanguage, Date rentalDuration, int length, double replacementcost, int ratings,
		String specialfeatures, List<Actor> actors, Category category) {
	super();
	Filmid = filmid;
	this.title = title;
	this.description = description;
	ReleaseYear = releaseYear;
	this.language = language;
	this.originalLanguage = originalLanguage;
	this.rentalDuration = rentalDuration;
	this.length = length;
	this.replacementcost = (int) replacementcost;
	this.ratings = ratings;
	this.specialfeatures = specialfeatures;
	this.actors = (List<Actor>) actors;
	this.category = category;
}

//getters and setters
	public int getFilmid() {
	return Filmid;
	}

	@Override
	public String toString() {
		return "Film [Filmid=" + Filmid + ", title=" + title + ", description=" + description + ", ReleaseYear="
				+ ReleaseYear + ", language=" + language + ", originalLanguage=" + originalLanguage
				+ ", rentalDuration=" + rentalDuration + ", length=" + length + ", replacementcost=" + replacementcost
				+ ", ratings=" + ratings + ", specialfeatures=" + specialfeatures + ", actors=" + actors + ", category="
				+ category + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Filmid;
		result = prime * result + ((ReleaseYear == null) ? 0 : ReleaseYear.hashCode());
		result = prime * result + ((actors == null) ? 0 : actors.hashCode());
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((language == null) ? 0 : language.hashCode());
		result = prime * result + length;
		result = prime * result + ((originalLanguage == null) ? 0 : originalLanguage.hashCode());
		result = prime * result + ratings;
		result = prime * result + ((rentalDuration == null) ? 0 : rentalDuration.hashCode());
		long temp;
		temp = Double.doubleToLongBits(replacementcost);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((specialfeatures == null) ? 0 : specialfeatures.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Film other = (Film) obj;
		if (Filmid != other.Filmid)
			return false;
		if (ReleaseYear == null) {
			if (other.ReleaseYear != null)
				return false;
		} else if (!ReleaseYear.equals(other.ReleaseYear))
			return false;
		if (actors == null) {
			if (other.actors != null)
				return false;
		} else if (!actors.equals(other.actors))
			return false;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (language == null) {
			if (other.language != null)
				return false;
		} else if (!language.equals(other.language))
			return false;
		if (length != other.length)
			return false;
		if (originalLanguage == null) {
			if (other.originalLanguage != null)
				return false;
		} else if (!originalLanguage.equals(other.originalLanguage))
			return false;
		if (ratings != other.ratings)
			return false;
		if (rentalDuration == null) {
			if (other.rentalDuration != null)
				return false;
		} else if (!rentalDuration.equals(other.rentalDuration))
			return false;
		if (Double.doubleToLongBits(replacementcost) != Double.doubleToLongBits(other.replacementcost))
			return false;
		if (specialfeatures == null) {
			if (other.specialfeatures != null)
				return false;
		} else if (!specialfeatures.equals(other.specialfeatures))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}

	public void setFilmid(int filmid) {
	Filmid = filmid;
	}

	public String getTitle() {
	return title;
	}

	public void setTitle(String title) {
	this.title = title;
	}

	public String getDescription() {
	return description;
	}

	public void setDescription(String description) {
	this.description = description;
	}

	public Date getReleaseYear() {
	return ReleaseYear;
	}

	public void setReleaseYear(Date releaseYear) {
	ReleaseYear = releaseYear;
	}

	public List<Language> getLanguage() {
	return language;
	}

	public void setLanguage(List<Language> language) {
	this.language = language;
	}

	public Language getOriginalLanguage() {
	return originalLanguage;
	}

	public void setOriginalLanguage(Language originalLanguage) {
	this.originalLanguage = originalLanguage;
	}

	public Date getRentalDuration() {
	return rentalDuration;
	}

	public void setRentalDuration(Date rentalDuration) {
	this.rentalDuration = rentalDuration;
	}

	public int getLength() {
	return length;
	}

	public void setLength(int length) {
	this.length = length;
	}

	public int getReplacementcost() {
	return replacementcost;
	}

	public void setReplacementcost(double replacementcost) {
	this.replacementcost = (int) replacementcost;
	}

	public int getRatings() {
	return ratings;
	}

	public void setRatings(int ratings) {
	this.ratings = ratings;
	}

	public String getSpecialfeatures() {
	return specialfeatures;
	}

	public void setSpecialfeatures(String specialfeatures) {
	this.specialfeatures = specialfeatures;
	}

	public List<Actor> getActors() {
	return (List<Actor>) actors;
	}

	public void setActors(List<Actor> actors2) {
	this.actors = (List<Actor>) actors2;
	}

	public Category getCategory() {
	return category;
	}

	public void setCategory(Category category) {
	this.category = category;
	}



	
}