
//Category Class
package com.flp.fms.domain;

public class Category {
	 @Override
	public String toString() {
		return "Category [CategoryId=" + CategoryId + ", Name=" + Name + "]";
	}

	private int CategoryId;
	 private String Name;
	
/*No argument Constructor*/public Category(){ }

//Argument Constructor
	public Category(int categoryId, String name) 
	{
	super();
	CategoryId = categoryId;
	Name = name;
	}
	
//Getters and Setters
	public int getCategoryId() {
	return CategoryId;
	}

	public void setCategoryId(int categoryId) {
	CategoryId = categoryId;
}

	public String getName() {
	return Name;
}

	public void setName(String name) {
	Name = name;
}







	 
	 
	 
	 
	 
	 
	 
	 
	
}
