
//Actor Class
package com.flp.fms.domain;

public class Actor {
	private int ActorId;
	private String FirstName;
	private String LastName;
	
/*No Argument constructor*/ public  Actor (){}
	
//Argument Constructor
		public Actor(int actorId, String firstName, String lastName) 
		{
		super();
		ActorId = actorId;
		FirstName = firstName;
		LastName = lastName;
		}
	
//getters and setters
		public int getActorId() {
		return ActorId;
		}

		public void setActorId(int actorId) {
		ActorId = actorId;
		}

		@Override
		public String toString() {
			return "Actor [ActorId=" + ActorId + ", FirstName=" + FirstName + ", LastName=" + LastName + "]";
		}

		public String getFirstName() {
		return FirstName;
		}

		public void setFirstName(String firstName) {
		FirstName = firstName;
		}

		public String getLastName() {
		return LastName;
		}

		public void setLastName(String lastName) {
		LastName = lastName;
	 	}
	
 
  }
