
//Language class
package com.flp.fms.domain;

public class Language {
	
	

	private int LanguageId;
	private String LanguageName;
	
	
/* No argument Constructor*/public Language() {}

@Override
public String toString() {
	return "Language [LanguageId=" + LanguageId + ", Name=" + LanguageName + "]";
}

	//Argument Constructor
	public Language(int languageId, String name) 
	{
		super();
		LanguageId = languageId;
		LanguageName = name;
		
	}
	
 //getters and setters
	public int getLanguageId() {
		return LanguageId;
	}

	public void setLanguageId(int languageId) {
		LanguageId = languageId;
	}

	public String getLanguageName() {
		return LanguageName;
	}

	public void setLanguageName(String name) {
		LanguageName = name;
	}

	
	

	
	
	
	
	
}
