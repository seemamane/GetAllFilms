function validateForm(){
	
	var flag = true;
	var title = film.filmTitle.value;
	var length = film.length.value;
	//var rating = film.rating.value;
	var cost = film.cost.value;
	
		
	if(title==""||title==null||!isValidTitle()){
		
		document.getElementById("title_div").innerHTML="*Please enter a valid title";
		flag = false;
	}
	else
		document.getElementById("title_div").innerHTML="";
	
	if(length==""||length==null||!isValidLength()){
		
		document.getElementById("length_div").innerHTML="*Please enter a value below 1000";
		flag = false;
	}
	else
		document.getElementById("length_div").innerHTML="";
	
	/*if(rating==""||rating==null||!isValidRating()){
		
		document.getElementById("rating_div").innerHTML="*Please give a rating 1-5";
		flag = false;
	}
	else
		document.getElementById("rating_div").innerHTML="";*/
	
	if(!isValidRentalDate()){
		
		document.getElementById("rental_div").innerHTML="*Invalid rental duration";
		flag = false;
	}
		
	else
		document.getElementById("rental_div").innerHTML="";
	
	
	if(cost==""||cost==null||!isValidNumber()){
		
		document.getElementById("cost_div").innerHTML="*Please enter a valid cost";
		flag = false;
	}
		
	else
		document.getElementById("cost_div").innerHTML="";
	
	return flag;
}


function isValidTitle(){
	
	var pattern=/[A-Za-z0-9@., ]+$/;
	
	if(document.getElementById("title").value.match(pattern))	
		return true;
	
	else
		return false;
}

function isValidLength(){
	
	var length = film.length.value;
	
	if(length>0 && length<=1000)
		return true;
	else
		return false;
}

function isValidRating(){
	
	var rating = film.rating.value;
	
	if(rating>0 && rating<=5)
		return true;
	else
		return false;
}

function isValidRentalDate(){
	
	var rentalDate = film.rentalDate.value;
	var releaseDate = film.releaseYear.value;
	 
    if(rentalDate >= releaseDate)
    	return true;
    else
    	return false;
}

function isValidNumber(){
	
	var numbers = /^[0-9]+(.)?[0-9]*$/;  
	var cost = film.cost.value;
	
    if(cost.match(numbers))  
    	return true;
    else
    	return false;

}
