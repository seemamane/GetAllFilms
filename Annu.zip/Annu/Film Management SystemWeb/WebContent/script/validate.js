function titleValidation()  
{   
		var filmname=film.filmname.value;
		var letters = /^[A-Za-z]+$/;  
	
		if(filmname.match(letters))  
		{  
			document.getElementById("titleerr").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("titleerr").innerHTML="*Please enter Title starts with alphabet"; 
			filmname.focus();  
			return false;  
		}  
} 

function lengthValidation(){
	
	var filmlength=film.length.value;
	
	if(isNaN(filmlength) || filmlength<1 || filmlength>1000){
		
		document.getElementById("lengtherr").innerHTML="*Please enter length between 1 to 1000";
		lengtherr.focus();
		return false;
		
	}
	else
		{
		document.getElementById("lengtherr").innerHTML="";
		return true;
		}
}

function ratingValidation(){
	
	var ratings=film.rating.value;
	if(isNaN(ratings)||ratings>1||ratings<5){
		
		document.getElementById("ratingserr").innerHTML="";
		
		return true;
		
	}
		
	else {
		document.getElementById("ratingserr").innerHTML="*Please enter ratings between 1 to 5";
		return false;
	}
	
}

function specialFeatureValidation(){
	
	var specialfeatures=film.specialfeatures.value;
	
	var letters = /[A-Za-z0-9.,! ]+/;
	
	
	if(specialfeatures.match(letters))  
	{  
		document.getElementById("featureErr").innerHTML="";
		return true;  
	}  
	else  
	{  
		document.getElementById("featureErr").innerHTML="*Please enter valid Special Features"; 
		specialfeatures.focus();  
		return false;  
	} 
	
}